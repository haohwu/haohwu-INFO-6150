export const fetchJobs = (jobs) => ({
  type: 'FETCH_JOBS',
  payload: jobs,
});
